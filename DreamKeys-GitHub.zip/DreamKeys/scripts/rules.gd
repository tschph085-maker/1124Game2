extends RefCounted
# Deterministic assessment. No random investment outcome affects mastery scores.
static func budget(items: Array, saving: int) -> Dictionary:
	var costs = [40,20,35,15,20]
	var spent = saving
	for i in range(5):
		if items[i]: spent += costs[i]
	var needs = items[0] and items[1]
	return {"pass": needs and saving >= 20 and spent <= 100, "total": spent, "needs": needs, "saved": saving >= 20}

static func investment(reserve: int, pots: Array, reason: int) -> Dictionary:
	var total = reserve
	var used = 0
	for n in pots:
		total += n
		if n > 0: used += 1
	return {"pass": total == 100 and reserve >= 20 and used >= 2 and reason == 1, "total": total, "reserve": reserve >= 20, "spread": used >= 2, "reason": reason == 1}

static func score(mistakes: int) -> int:
	return maxi(60,100-mistakes*10)

static func quiz_correct(phase: String, q: int, answer: int) -> bool:
	var keys = [1,0,2,1] if phase == "pre" else [2,1,0,2]
	return answer == keys[q]
