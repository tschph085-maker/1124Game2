extends Node3D
const Rules = preload("res://scripts/rules.gd")
const GOLD = Color("edc57d")
const INK = Color("102429")
const CREAM = Color("f2ead7")
const MUTED = Color("a5b9b5")
const GREEN = Color("78d2bc")
var world: Node3D
var hero: Node3D
var camera: Camera3D
var key_model: Node3D
var key_light: OmniLight3D
var hud: Control
var overlay: Control
var theme_ui: Theme
var stage = "menu"
var level = 1
var has_key = false
var scores = [0,0]
var mistakes = [0,0]
var attempts = [0,0]
var picked = [false,false,false,false,false]
var saving = 0
var reserve = 0
var pots = [0,0,0]
var reason = -1
var q_index = 0
var pre_answers: Array = []
var post_answers: Array = []
var pre_score = 0
var post_score = 0
var quiz_phase = "pre"
var quiz_locked = false
var ui_box: VBoxContainer
var feedback_label: Label
var counter: Label
var status_label: Label
var position_hint: Label
var total_label: Label
var interaction_panel: PanelContainer
var ui_open = false
var t = 0.0
var jump_v = 0.0
var moving_left = false
var moving_right = false
var sound_enabled = true
var sound_player: AudioStreamPlayer
var music_player: AudioStreamPlayer
var particle_nodes: Array[MeshInstance3D] = []
var notice = ""
var notice_timer = 0.0
var auto_test = false
var pending_move = false

func _ready():
	theme_ui = Theme.new()
	theme_ui.default_font = load("res://assets/DreamKeysTC.ttf")
	theme_ui.default_font_size = 19
	build_world()
	var canvas = CanvasLayer.new()
	add_child(canvas)
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.theme = theme_ui
	canvas.add_child(hud)
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.theme = theme_ui
	canvas.add_child(overlay)
	sound_player = AudioStreamPlayer.new()
	add_child(sound_player)
	sound_player.stream = load("res://assets/chime.wav")
	music_player = AudioStreamPlayer.new()
	add_child(music_player)
	music_player.stream = load("res://assets/room.wav")
	music_player.volume_db = -22
	music_player.finished.connect(func():
		if sound_enabled: music_player.play())
	show_menu()
	auto_test = "--capture" in OS.get_cmdline_user_args()
	if auto_test: capture_run.call_deferred()

func style(bg: Color, border = Color("3b5555"), radius = 16) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 24
	s.content_margin_right = 24
	s.content_margin_top = 20
	s.content_margin_bottom = 20
	return s

func label(text: String, size = 20, color = CREAM) -> Label:
	var l = Label.new()
	l.text = text
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func button(text: String, fn: Callable, primary = false) -> Button:
	var b = Button.new()
	b.text = text
	b.custom_minimum_size.y = 48
	b.add_theme_font_size_override("font_size",18)
	b.add_theme_color_override("font_color",INK if primary else CREAM)
	b.add_theme_color_override("font_hover_color",INK if primary else GOLD)
	b.add_theme_color_override("font_focus_color",INK if primary else GOLD)
	b.add_theme_stylebox_override("normal",style(GOLD if primary else Color("19353a"),GOLD if primary else Color("46605e"),9))
	b.add_theme_stylebox_override("hover",style(Color("ffdc99") if primary else Color("25484b"),GOLD,9))
	b.add_theme_stylebox_override("pressed",style(Color("c89c54") if primary else Color("315853"),GOLD,9))
	b.add_theme_stylebox_override("focus",style(Color(0,0,0,0),GREEN,9))
	for state in ["normal","hover","pressed","focus"]:
		var box = b.get_theme_stylebox(state)
		box.content_margin_top = 8
		box.content_margin_bottom = 8
		box.content_margin_left = 14
		box.content_margin_right = 14
	b.pressed.connect(fn)
	return b

func panel_at(parent: Control, rect: Rect2, color = Color(.035,.075,.085,.96)) -> VBoxContainer:
	var p = PanelContainer.new()
	p.position = rect.position
	p.size = rect.size
	p.add_theme_stylebox_override("panel",style(color))
	parent.add_child(p)
	var v = VBoxContainer.new()
	v.add_theme_constant_override("separation",12)
	p.add_child(v)
	return v

func clear_ui():
	for n in overlay.get_children():
		n.queue_free()
		overlay.remove_child(n)
	ui_open = false

func clear_hud():
	for n in hud.get_children():
		n.queue_free()
		hud.remove_child(n)

func build_world():
	world = Node3D.new()
	add_child(world)
	var env = WorldEnvironment.new()
	var e = Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color("111f28")
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color("9db4b4")
	e.ambient_light_energy = .22
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.environment = e
	add_child(env)
	var sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-35,-30,0)
	sun.light_color = Color("b8d6dc")
	sun.light_energy = .25
	sun.shadow_enabled = true
	add_child(sun)
	camera = Camera3D.new()
	camera.position = Vector3(0,4.8,13.8)
	camera.fov = 52
	add_child(camera)
	camera.look_at(Vector3(0,2.7,0))
	hero = load("res://models/explorer.glb").instantiate()
	add_child(hero)
	hero.position = Vector3(-6,0,1)
	var lantern = OmniLight3D.new()
	lantern.position = Vector3(.45,.6,.15)
	lantern.light_color = GOLD
	lantern.light_energy = 1.5
	lantern.omni_range = 2.7
	hero.add_child(lantern)
	key_model = load("res://models/key.glb").instantiate()
	key_model.position = Vector3(0,2.7,.2)
	add_child(key_model)
	key_model.visible = false
	key_light = OmniLight3D.new()
	key_light.position = Vector3(0,2.9,1)
	key_light.light_color = GOLD
	key_light.omni_range = 5
	key_light.light_energy = 0
	add_child(key_light)
	for pos in [Vector3(-2,5,0),Vector3(6,6,-1),Vector3(-6,3,1)]:
		var light = OmniLight3D.new()
		light.position = pos
		light.light_color = Color("ffc77c")
		light.light_energy = 1.2
		light.omni_range = 9
		light.shadow_enabled = true
		add_child(light)
	var dustmat = StandardMaterial3D.new()
	dustmat.albedo_color = Color("c7b47a")
	dustmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for i in range(45):
		var dust = MeshInstance3D.new()
		var mesh = SphereMesh.new()
		mesh.radius = .012
		mesh.height = .024
		mesh.radial_segments = 4
		mesh.rings = 2
		dust.mesh = mesh
		dust.material_override = dustmat
		dust.position = Vector3(randf_range(-11,11),randf_range(.3,7),randf_range(-2,3))
		add_child(dust)
		particle_nodes.append(dust)
	load_room(1)

func load_room(n: int):
	for child in world.get_children():
		world.remove_child(child)
		child.queue_free()
	var scene = load("res://models/room%d.glb" % n).instantiate()
	world.add_child(scene)

func _process(delta):
	t += delta
	for i in range(particle_nodes.size()):
		particle_nodes[i].position.y += sin(t*.4+i)*delta*.025
	key_model.rotation.y += delta*.8
	key_model.position.y = 2.7 + sin(t*2)*.14
	if stage == "play" and not ui_open:
		var x = 0.0
		if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT) or moving_left: x -= 1
		if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT) or moving_right: x += 1
		var z = 0.0
		if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP): z -= 1
		if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN): z += 1
		hero.position.x = clampf(hero.position.x+x*delta*3.4,-9.8,9.8)
		hero.position.z = clampf(hero.position.z+z*delta*2.5,-.1,2.4)
		if x != 0:
			hero.rotation.y = lerp_angle(hero.rotation.y,-x*.45,delta*8)
			hero.rotation.z = sin(t*14)*.035
		else: hero.rotation.z = 0
		jump_v -= delta*12
		hero.position.y = maxf(0,hero.position.y+jump_v*delta)
		if hero.position.y == 0: jump_v = 0
		if is_instance_valid(position_hint):
			if absf(hero.position.x) < 2.7 and not has_key: position_hint.text = "按 E 或點「互動」：開始解謎"
			elif hero.position.x > 6.7: position_hint.text = "按 E 開門" if has_key else "門鎖住了，需要先取得 KEY"
			else: position_hint.text = "帶著提燈，走向中央的發光工作桌"
	if notice_timer > 0:
		notice_timer -= delta
		if is_instance_valid(status_label): status_label.text = notice
	elif is_instance_valid(status_label) and stage == "play":
		status_label.text = "KEY  1 / 1 · 前往右側出口" if has_key else "KEY  0 / 1 · 完成桌上的挑戰"

func _unhandled_key_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_E and stage == "play" and not ui_open: interact()
		if event.physical_keycode == KEY_SPACE and stage == "play" and not ui_open and hero.position.y == 0: jump_v = 4.8
		if event.physical_keycode == KEY_ESCAPE and stage == "play" and ui_open: close_puzzle()

func show_menu():
	stage = "menu"
	clear_ui()
	clear_hud()
	hero.position = Vector3(2.8,0,1)
	var v = panel_at(overlay,Rect2(64,105,575,590))
	v.add_child(label("D R E A M   K E Y S     /     理 財 冒 險",15,GOLD))
	v.add_child(label("小小夢境",64))
	v.add_child(label("理財鑰匙",36,GOLD))
	v.add_child(label("在巨人的屋子裡，\n把每一個小選擇，變成長大的力量。",23))
	v.add_child(label("兩個房間 · 兩把鑰匙 · 一趟理財練習",17,MUTED))
	v.add_child(button("點亮提燈，開始冒險",start_new,true))
	v.add_child(button("玩法與教學目標",show_help))
	v.add_child(label("適合國小中高年級｜約 10–15 分鐘｜無倒數計時",15,MUTED))
	var note = label("01  願望雜貨屋\n02  種子投資室",20,GOLD)
	note.position = Vector2(900,640)
	note.size = Vector2(320,100)
	hud.add_child(note)

func show_help():
	clear_ui()
	var v = panel_at(overlay,Rect2(230,85,820,630))
	v.add_child(label("提燈旅人的小手冊",34,GOLD))
	v.add_child(label("移動：WASD / 方向鍵，或畫面下方按鈕\n跳躍：空白鍵　互動：E 或「互動」按鈕\n關閉解謎：Esc 或「回到房間」",22))
	v.add_child(label("① 預算：先照顧需要，再為想要做選擇。\n② 投資：留備用金、分散風險，了解可能虧損。",23))
	v.add_child(label("每關首次正確 100 分；每次未通過扣 10 分，最低 60 分。\n答錯會給提示，可以重試。看提示與探索不扣分。\n前後測各 4 題，獨立於闖關分數；不以速度計分。",19,MUTED))
	v.add_child(label("此為簡化教學情境，投資結果不是預測或報酬承諾。\n不收集姓名、不連接帳戶；成績只儲存在這個瀏覽器。",17,MUTED))
	v.add_child(button("回到封面",show_menu,true))

func start_new():
	scores = [0,0]; mistakes = [0,0]; attempts = [0,0]
	pre_answers.clear(); post_answers.clear(); pre_score = 0; post_score = 0
	picked = [false,false,false,false,false]; saving = 0; reserve = 0; pots = [0,0,0]; reason = -1
	level = 1; has_key = false; key_model.visible = false; key_light.light_energy = 0
	load_room(1)
	music_player.play()
	quiz_phase = "pre"; q_index = 0
	show_quiz()

func quiz_data() -> Array:
	if quiz_phase == "pre":
		return [
			["明天上學必須搭車，手上只剩 30 元。先做什麼？",["全買貼紙","保留 20 元車資","借錢買玩具"],"先照顧必要支出，再考慮想要的東西。"],
			["有 100 元，午餐花 40 元、車資花 20 元，還剩多少？",["40 元","60 元","20 元"],"100 − 40 − 20 = 40 元。先列出預算，就不易超支。"],
			["把所有投資放在同一家公司，可能有什麼問題？",["一定賺更多","保證不虧錢","風險太集中"],"分散可以降低集中風險，但不能保證不虧損。"],
			["有人說投資一定賺錢，哪個想法比較合理？",["把備用金全投入","先了解風險，知道可能虧損","不必了解就跟著買"],"任何投資都需要理解風險，不能只相信獲利承諾。"]]
	return [
		["小晴有 80 元，明天需要 30 元午餐費。她應該先？",["先買 70 元玩具","全部拿去投資","先留午餐費，再規劃剩下的錢"],"必要支出優先；剩餘的錢再安排儲蓄或想要的東西。"],
		["有 120 元，午餐 50 元、車資 30 元，還剩多少？",["80 元","40 元","20 元"],"120 − 50 − 30 = 40 元。這是預算計算的新例子。"],
		["只買一種種子，遇到病蟲害可能全部受影響。可以怎麼做？",["分配到不同種類，同時了解各種風險","全部加買相同種子","相信這種種子永遠不會失敗"],"分散能降低單一風險，但仍可能因共同因素一起虧損。"],
		["投資前，哪個做法較合適？",["把下週生活費全投入","只看別人賺多少","保留備用金，了解可能虧損"],"先照顧生活需要，投資只使用能承受風險的資源。"]]

func show_quiz():
	stage = "quiz"
	clear_ui(); clear_hud()
	quiz_locked = false
	var data = quiz_data()[q_index]
	var v = panel_at(overlay,Rect2(220,88,840,624))
	v.add_child(label("出發前的小觀察" if quiz_phase == "pre" else "冒險後的小發現",18,GOLD))
	v.add_child(label("%02d / 04" % (q_index+1),30,MUTED))
	v.add_child(label(data[0],29))
	v.add_child(label("不計入關卡分數，照你的想法回答。" if quiz_phase == "pre" else "試著把學到的觀念，用在新的情境。",17,MUTED))
	for i in range(3):
		var idx = i
		v.add_child(button(["A   ","B   ","C   "][i]+data[1][i],func(): answer_quiz(idx)))
	feedback_label = label("",19,GREEN)
	v.add_child(feedback_label)
	ui_box = v

func answer_quiz(answer: int):
	if quiz_locked: return
	quiz_locked = true
	var correct = Rules.quiz_correct(quiz_phase,q_index,answer)
	if quiz_phase == "pre":
		pre_answers.append(answer)
		if correct: pre_score += 1
	else:
		post_answers.append(answer)
		if correct: post_score += 1
	for n in ui_box.get_children():
		if n is Button: n.disabled = true
	# No feedback in pre-test, so it remains a baseline rather than instruction.
	feedback_label.text = "已記錄你的想法。" if quiz_phase == "pre" else (("答對了！ " if correct else "一起記住： ")+quiz_data()[q_index][2])
	ui_box.add_child(button("開始第一關" if quiz_phase == "pre" and q_index == 3 else ("查看成果" if q_index == 3 else "下一題"),next_quiz,true))

func next_quiz():
	q_index += 1
	if q_index < 4: show_quiz()
	elif quiz_phase == "pre": begin_level(1)
	else: show_results()

func begin_level(n: int):
	level = n; stage = "play"; has_key = false
	key_model.visible = false; key_light.light_energy = 0
	hero.position = Vector3(-6,0,1); hero.rotation = Vector3.ZERO
	load_room(n)
	clear_ui(); build_hud()
	toast("走到工作桌旁，按 E 或點「互動」開始。")

func build_hud():
	clear_hud()
	var v = panel_at(hud,Rect2(28,24,530,126),Color(.035,.075,.085,.9))
	v.add_child(label("0%d / 02     %s" % [level,"願望雜貨屋" if level == 1 else "種子投資室"],25,GOLD))
	status_label = label("",17,CREAM)
	v.add_child(status_label)
	var score_box = panel_at(hud,Rect2(1015,24,237,126),Color(.035,.075,.085,.9))
	score_box.add_child(label("本關得分",16,MUTED))
	counter = label("待解鎖 / 100",26,GOLD)
	score_box.add_child(counter)
	position_hint = label("",18)
	position_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	position_hint.position = Vector2(280,665)
	position_hint.size = Vector2(720,40)
	hud.add_child(position_hint)
	var bottom = HBoxContainer.new()
	bottom.position = Vector2(28,722)
	bottom.add_theme_constant_override("separation",10)
	hud.add_child(bottom)
	for dir in [-1,1]:
		var d = dir
		var b = button("左移" if d < 0 else "右移",func(): pass)
		b.custom_minimum_size.x = 90
		b.button_down.connect(func():
			if d < 0: moving_left = true
			else: moving_right = true)
		b.button_up.connect(func():
			if d < 0: moving_left = false
			else: moving_right = false)
		bottom.add_child(b)
	bottom.add_child(button("跳躍",func():
		if not ui_open and hero.position.y == 0: jump_v = 4.8))
	bottom.add_child(button("互動  E",interact,true))
	var audio = button("聲音：開" if sound_enabled else "聲音：關",func(): toggle_audio())
	audio.position = Vector2(1070,722); audio.size.x = 182
	hud.add_child(audio)

func toggle_audio():
	sound_enabled = not sound_enabled
	if sound_enabled: music_player.play()
	else: music_player.stop()
	build_hud()
	if has_key: counter.text = "%d / 100" % scores[level-1]

func toast(text: String):
	notice = text; notice_timer = 4

func interact():
	if stage != "play" or ui_open: return
	if hero.position.x > 6.7:
		if has_key: level_summary()
		else: toast("門還鎖著。完成工作桌的挑戰，就能拿到 KEY。")
	elif absf(hero.position.x) < 2.7:
		if has_key: toast("KEY 已在口袋裡，走到右側的門開鎖吧！")
		elif level == 1: show_budget()
		else: show_investment()
	else: toast("繼續走向房間中央的工作桌。")

func puzzle_base(title: String, subtitle: String) -> VBoxContainer:
	clear_ui(); ui_open = true
	moving_left = false; moving_right = false
	var v = panel_at(overlay,Rect2(600,145,650,555))
	v.add_theme_constant_override("separation",7)
	v.add_child(label(title,29,GOLD))
	v.add_child(label(subtitle,17,MUTED))
	return v

func close_puzzle():
	clear_ui(); ui_open = false

func show_budget():
	var v = puzzle_base("01   把零用錢安排好", "你有 100 元。先買午餐與車票，至少存下 20 元。")
	var grid = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation",8)
	grid.add_theme_constant_override("v_separation",7)
	v.add_child(grid)
	var names = ["午餐 · 40 元","車票 · 20 元","玩具 · 35 元","糖果 · 15 元","讀物 · 20 元"]
	for i in range(5):
		var idx = i
		var b = button(("✓  " if picked[i] else "+  ")+names[i],func():
			picked[idx] = not picked[idx]; show_budget())
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if picked[i]: b.add_theme_stylebox_override("normal",style(Color("315c53"),GREEN,9))
		grid.add_child(b)
	var row = HBoxContainer.new()
	v.add_child(row)
	var savings_label = label("存入儲蓄",19)
	savings_label.custom_minimum_size.x = 150
	row.add_child(savings_label)
	row.add_child(button("− 10",func(): saving = maxi(0,saving-10); show_budget()))
	var amount = label("%d 元" % saving,23,GOLD)
	amount.custom_minimum_size.x = 100
	amount.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(amount)
	row.add_child(button("+ 10",func(): saving = mini(100,saving+10); show_budget()))
	var result = Rules.budget(picked,saving)
	v.add_child(label("已安排 %d 元  /  可用 %d 元" % [result.total,100-result.total],21,GREEN if result.total <= 100 else Color("ffb9a5")))
	feedback_label = label("需要先照顧；想要可以等一等。",18,MUTED)
	v.add_child(feedback_label)
	v.add_child(button("確認預算，解鎖 KEY",check_budget,true))
	v.add_child(button("回到房間",close_puzzle))

func check_budget():
	attempts[0] += 1
	var r = Rules.budget(picked,saving)
	if r["pass"]: grant_key()
	else:
		mistakes[0] += 1
		if not r.needs: feedback_label.text = "提示：上學的午餐與車票都要先安排。"
		elif not r.saved: feedback_label.text = "提示：請至少存下 20 元，留給未來的需要。"
		else: feedback_label.text = "超過 100 元了。試著拿掉一項想要的東西。"
		feedback_label.add_theme_color_override("font_color",Color("ffb9a5"))

func show_investment():
	var v = puzzle_base("02   讓種子分散風險", "分配 100 枚代幣：備用金至少 20，至少選 2 種種子。")
	var names = ["備用金 · 不投入種子","豆子 · 波動較小","向日葵 · 波動中等","南瓜 · 波動較大"]
	for i in range(4):
		var idx = i
		var row = HBoxContainer.new()
		v.add_child(row)
		var l = label(names[i],17)
		l.custom_minimum_size.x = 280
		row.add_child(l)
		row.add_child(button("−",func(): adjust_pot(idx,-20)))
		var n = reserve if i == 0 else pots[i-1]
		var val = label(" %d " % n,21,GOLD)
		val.custom_minimum_size.x = 58
		val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		row.add_child(val)
		row.add_child(button("+",func(): adjust_pot(idx,20)))
	var total = reserve+pots[0]+pots[1]+pots[2]
	v.add_child(label("已分配 %d / 100  ·  每次增減 20 枚" % total,18,GREEN if total == 100 else MUTED))
	var choice = OptionButton.new()
	choice.custom_minimum_size.y = 46
	choice.add_item("選擇你的理由……")
	choice.add_item("分散以後，一定不會虧損")
	choice.add_item("降低集中風險，但仍可能虧損")
	choice.add_item("選最會賺的，投入全部代幣")
	choice.selected = reason+1
	choice.item_selected.connect(func(idx): reason = idx-1)
	v.add_child(choice)
	feedback_label = label("種子是投資比喻；備用金不代表真實存款產品。",16,MUTED)
	v.add_child(feedback_label)
	v.add_child(button("確認配置，觀察結果",check_investment,true))
	v.add_child(button("回到房間",close_puzzle))

func adjust_pot(idx: int, delta: int):
	if idx == 0: reserve = clampi(reserve+delta,0,100)
	else: pots[idx-1] = clampi(pots[idx-1]+delta,0,100)
	show_investment()

func check_investment():
	attempts[1] += 1
	var r = Rules.investment(reserve,pots,reason)
	if r["pass"]: show_scenario()
	else:
		mistakes[1] += 1
		if r.total != 100: feedback_label.text = "請剛好分配 100 枚代幣，多的要減少，少的再安排。"
		elif not r.reserve: feedback_label.text = "先留至少 20 枚備用金，生活需要不能冒險。"
		elif not r.spread: feedback_label.text = "至少分給 2 種不同種子，別讓風險集中。"
		else: feedback_label.text = "分散不等於保證獲利。請再想想可能虧損的情況。"
		feedback_label.add_theme_color_override("font_color",Color("ffb9a5"))

func show_scenario():
	clear_ui(); ui_open = true
	var v = panel_at(overlay,Rect2(260,110,760,580))
	v.add_child(label("一場風雨過後",35,GOLD))
	v.add_child(label("這次教學情境：豆子 −10%、向日葵 +20%、南瓜 −50%。\n這是固定示例，不代表真實投資機率或預期報酬。",21))
	var final_value = reserve+pots[0]*.9+pots[1]*1.2+pots[2]*.5
	v.add_child(label("備用金 %d 枚，仍可應付臨時需要。" % reserve,24,GREEN))
	v.add_child(label("投入前 100 枚 → 情境後 %.0f 枚" % final_value,28,GOLD))
	v.add_child(label("分散能減少單一種子的影響，仍可能整體虧損。\n你的得分來自規劃與理解，不取決於賺或賠。",22))
	v.add_child(button("我理解了，領取 KEY",grant_key,true))

func grant_key():
	scores[level-1] = Rules.score(mistakes[level-1])
	has_key = true
	key_model.visible = true; key_light.light_energy = 1.2
	clear_ui(); ui_open = false
	counter.text = "%d / 100" % scores[level-1]
	if sound_enabled: sound_player.play()
	toast("獲得 KEY！本關 %d 分。帶著鑰匙到右側出口。" % scores[level-1])

func level_summary():
	clear_ui(); ui_open = true
	var v = panel_at(overlay,Rect2(310,140,660,520))
	v.add_child(label("第一把鑰匙 · 預算" if level == 1 else "第二把鑰匙 · 風險",22,GOLD))
	v.add_child(label("%d / 100" % scores[level-1],65))
	v.add_child(label("完成 %d 次配置檢查，找到通關的方法。" % attempts[level-1],21))
	v.add_child(label("先滿足需要，再安排儲蓄與想要。" if level == 1 else "保留備用金、分散配置，理解仍可能虧損。",23,GREEN))
	v.add_child(button("打開第二個房間" if level == 1 else "完成冒險，看看學到了什麼",func():
		if level == 1: begin_level(2)
		else:
			quiz_phase = "post"; q_index = 0; show_quiz(),true))

func show_results():
	stage = "results"
	clear_ui(); clear_hud()
	var v = panel_at(overlay,Rect2(170,55,940,690))
	v.add_child(label("兩把鑰匙，一段成長",39,GOLD))
	v.add_child(label("你帶走的，不只是鑰匙。",23))
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation",24)
	v.add_child(row)
	row.add_child(label("預算關卡\n%d / 100" % scores[0],27,GREEN))
	row.add_child(label("投資關卡\n%d / 100" % scores[1],27,GREEN))
	row.add_child(label("闖關總分\n%d / 200" % (scores[0]+scores[1]),27,GOLD))
	var gain = post_score-pre_score
	v.add_child(label("觀念檢核  %d / 4 → %d / 4    （%+d 題）" % [pre_score,post_score,gain],27))
	var concepts = ["需要與想要","預算計算","分散風險","虧損與備用金"]
	for i in range(4):
		var before = Rules.quiz_correct("pre",i,pre_answers[i])
		var after = Rules.quiz_correct("post",i,post_answers[i])
		var msg = "持續掌握" if before and after else ("本次有進步" if after else "再練習一次")
		v.add_child(label("%s  ·  %s" % [concepts[i],msg],19,GREEN if after else GOLD))
	v.add_child(label("這是本次練習的表現，不代表已證實長期學習成效。\n下次購物前，試著寫一張自己的小預算表。",17,MUTED))
	var actions = HBoxContainer.new()
	actions.add_theme_constant_override("separation",12)
	v.add_child(actions)
	actions.add_child(button("下載學習紀錄",download_report,true))
	actions.add_child(button("重新挑戰",start_new))
	actions.add_child(button("回到封面",show_menu))
	save_progress()

func report() -> Dictionary:
	return {"game":"Dream Keys", "version":"1.0.0", "level_scores":scores, "attempts":attempts, "pre_correct":pre_score, "post_correct":post_score, "change_correct":post_score-pre_score, "pre_answers":pre_answers, "post_answers":post_answers, "note":"本次練習紀錄，非長期學習成效證據；不含姓名。"}

func save_progress():
	var f = FileAccess.open("user://last_result.json",FileAccess.WRITE)
	if f: f.store_string(JSON.stringify(report(),"  "))

func download_report():
	var text = JSON.stringify(report(),"  ")
	if OS.has_feature("web"):
		JavaScriptBridge.download_buffer(text.to_utf8_buffer(),"dream-keys-learning.json","application/json")
	else:
		var f = FileAccess.open("user://dream-keys-learning.json",FileAccess.WRITE)
		if f: f.store_string(text)
		OS.shell_open(OS.get_user_data_dir())

func capture_run():
	await get_tree().create_timer(3).timeout
	RenderingServer.force_draw()
	get_viewport().get_texture().get_image().save_png("res://../preview-menu.png")
	start_new()
	for i in range(4):
		answer_quiz([1,0,0,0][i]); next_quiz()
	hero.position.x = -.8
	await get_tree().create_timer(1).timeout
	RenderingServer.force_draw()
	get_viewport().get_texture().get_image().save_png("res://../preview-room.png")
	show_budget()
	await get_tree().create_timer(.5).timeout
	RenderingServer.force_draw()
	get_viewport().get_texture().get_image().save_png("res://../preview-budget.png")
	picked = [true,true,false,false,true]; saving = 20
	check_budget()
	assert(has_key and scores[0] == 100)
	hero.position.x = 8; interact(); begin_level(2)
	hero.position.x = 0; show_investment()
	reserve = 20; pots = [40,40,0]; reason = 1
	check_investment(); grant_key()
	assert(has_key and scores[1] == 100)
	quiz_phase = "post"; q_index = 0; show_quiz()
	for i in range(4):
		answer_quiz([2,1,0,2][i]); next_quiz()
	await get_tree().create_timer(.7).timeout
	RenderingServer.force_draw()
	get_viewport().get_texture().get_image().save_png("res://../preview-results.png")
	print("DREAMKEYS_FLOW_OK pre=%d post=%d total=%d" % [pre_score,post_score,scores[0]+scores[1]])
	get_tree().quit()
