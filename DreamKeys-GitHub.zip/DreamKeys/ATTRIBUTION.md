# 來源與授權

- 遊戲程式、Blender 建模腳本、角色場景與合成聲音：為本專案製作。
- 繁體中文字型：Google Fonts 提供之 Noto Sans TC（Adobe，SIL OFL 1.1），經固定 500 字重及遊戲文字子集化。授權全文保留於 assets/OFL.txt。新增中文字時可替換成完整 Noto Sans TC。
- Godot Engine Web 執行環境：MIT license，版權與第三方授權可查 https://godotengine.org/license/ 。原始發行版 https://github.com/godotengine/godot-builds/releases/tag/4.7.2-stable 。
- 美術方向參考 Little Nightmares 的物件尺度與場景光影；未使用其角色、美術、音樂與遊戲素材。參考頁面 https://store.steampowered.com/app/424840/Little_Nightmares/ 。
