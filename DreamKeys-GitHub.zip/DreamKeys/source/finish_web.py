"""Run after Godot Web export. Idempotent, no build dependencies."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'docs/index.html'
s=p.read_text()
if 'dreamkeys-tools' not in s:
 s=s.replace('<html lang="en">','<html lang="zh-Hant">')
 css='''<style id="dreamkeys-tools">
html,body{background:#101e26!important}body{margin:0}#tools{position:fixed;right:12px;top:10px;z-index:20;display:flex;gap:8px;font:14px system-ui}#tools button{background:#142d32dd;color:#edc57d;border:1px solid #536b66;border-radius:8px;padding:9px 13px;cursor:pointer}#screen-note{position:fixed;bottom:4px;left:0;right:0;text-align:center;color:#a6b9b5;font:12px system-ui;pointer-events:none}@media(max-width:600px) and (orientation:portrait){#screen-note{font-size:14px;bottom:16px}}
</style>'''
 s=s.replace('</head>',css+'</head>')
 controls='''<div id="tools"><button type="button" id="fullscreen" aria-label="切換全螢幕">全螢幕</button><button type="button" id="help" aria-label="顯示操作說明">操作說明</button></div><div id="screen-note">建議橫向遊玩 · WASD 移動 · E 互動 · 空白鍵跳躍</div><script>document.getElementById('fullscreen').onclick=()=>{if(document.fullscreenElement){document.exitFullscreen()}else{document.documentElement.requestFullscreen().catch(()=>{})}};document.getElementById('help').onclick=()=>alert('WASD / 方向鍵移動，空白鍵跳躍，E 互動。也可用畫面下方按鈕。\u005cn\u005cn走近中央工作桌解謎，取得 KEY 後，到右側的門按互動。\u005cn\u005cn建議使用桌機或平板橫向遊玩。');</script>'''
 s=s.replace('</body>',controls+'</body>')
 p.write_text(s)
(root/'docs/.nojekyll').touch()
print('Web shell ready')
