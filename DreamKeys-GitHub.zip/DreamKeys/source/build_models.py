"""Original Dream Keys meshes. Run with Blender --background --python this_file."""
import bpy, math, random
from pathlib import Path
from mathutils import Vector
random.seed(12)
ROOT=Path(__file__).resolve().parents[1]
M={}
def mat(n,c,metal=0,rough=.65,emit=0):
 m=bpy.data.materials.new(n); m.diffuse_color=(*c,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 M[n]=m
for n,c,me,ro,em in [('wood',(.12,.065,.035),0,.65,0),('edge',(.23,.13,.065),0,.5,0),('teal',(.075,.19,.18),0,.8,0),('wall',(.115,.19,.175),0,.9,0),('gold',(.72,.43,.13),.65,.3,0),('dark',(.018,.027,.035),0,.8,0),('cloth',(.08,.39,.37),0,.8,0),('skin',(.65,.42,.25),0,.8,0),('glow',(.9,.57,.18),.1,.3,2),('paper',(.63,.54,.34),0,.8,0),('leaf',(.12,.34,.18),0,.8,0),('clay',(.35,.12,.065),0,.8,0),('blue',(.13,.23,.33),0,.7,0),('red',(.32,.1,.08),0,.7,0)]:mat(n,c,me,ro,em)
def reset():
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def cube(n,loc,scale,ma,bevel=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  m=o.modifiers.new('Soft worn edges','BEVEL');m.width=bevel;m.segments=2
  bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=m.name)
 o.data.materials.append(M[ma]);return o
def uv(n,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=1,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(M[ma]);bpy.ops.object.shade_smooth();return o
def cyl(n,loc,r,depth,ma):
 bpy.ops.mesh.primitive_cylinder_add(vertices=16,radius=r,depth=depth,location=loc);o=bpy.context.object;o.name=n;o.data.materials.append(M[ma]);return o
def bar(n,a,b,r,ma):
 d=Vector(b)-Vector(a);o=cyl(n,(Vector(a)+Vector(b))/2,r,d.length,ma);o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o
def save(n):
 bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'source'/'blender'/f'{n}.blend'))
 bpy.ops.export_scene.gltf(filepath=str(ROOT/'models'/f'{n}.glb'),export_format='GLB',export_yup=True,export_cameras=False,export_lights=False)
def cabinet(x,y,w,h):
 cube('Cabinet carcass',(x,y,h/2),(w,1.15,h),'wood',.08)
 cube('Crown',(x,y,h),(w+.25,1.35,.18),'edge')
 cube('Plinth',(x,y,.2),(w+.2,1.3,.3),'edge')
 for i in range(int(h/.8)):
  z=.65+i*.8
  cube('Drawer',(x,y-.61,z),(w-.18,.12,.68),'edge')
  for dx in [-.22,.22]:bar('Drawer brass handle',(x+dx-.07,y-.72,z),(x+dx+.07,y-.72,z),.035,'gold')
def lamp(x,y,z):
 bar('Hanging cable',(x,y,9),(x,y,z+.25),.028,'dark')
 bpy.ops.mesh.primitive_cone_add(vertices=24,radius1=.55,radius2=.16,depth=.3,location=(x,y,z+.25));bpy.context.object.data.materials.append(M['gold'])
 uv('Warm bulb',(x,y,z),(.15,.15,.2),'glow')
def room(level):
 reset()
 for i in range(24):
  for j in range(4):
   cube('Floor plank',(-11.5+i,-3+j*2,-.16),( .98,1.98,.25),'wood',.015)
 cube('Wallpaper',(0,3.5,4.5),(24,.25,9),'wall')
 for z in [.35,2.1,8.6]:cube('Wall moulding',(0,3.26,z),(24,.16,.1),'edge')
 for x in range(-11,12):
  cube('Wall panel batten',(x,3.3,1.1),(.035,.08,2),'edge',0)
  for z in range(3,9):
   o=cube('Wallpaper diamond',(x,3.31,z),(.14,.025,.25),'teal',0);o.rotation_euler[1]=.65
 cabinet(-8,2.5,2.4,7.5);cabinet(-4.8,2.5,1.5,5.7);cabinet(4.5,2.5,2.1,7)
 # door large enough to dwarf the explorer
 cube('Door frame',(8.3,3.05,2.5),(3,.45,5),'edge',.08)
 cube('Locked door',(8.3,2.77,2.45),(2.65,.13,4.6),'teal',.06)
 for z in [1.3,3.5]:cube('Door raised panel',(8.3,2.64,z),(2.12,.12,1.65),'wood',.05)
 uv('Door handle',(9.1,2.45,2.2),(.12,.14,.12),'gold')
 cube('Key escutcheon',(8.85,2.5,1.8),(.22,.1,.34),'gold')
 lamp(-2,0,5.2);lamp(6,1,6.2)
 # central interactive desk, accessible in front
 cube('Workbench top',(0,1.5,1.7),(4.4,1.6,.22),'edge',.1)
 for x in [-1.8,1.8]:
  for y in [.95,2.05]:cube('Table leg',(x,y,.8),(.18,.18,1.6),'wood')
 if level==1:
  cube('Cash register base',(-.8,1.5,2.05),(1.2,.7,.5),'teal',.08)
  cube('Register display',(-.8,1.7,2.55),(.75,.18,.45),'gold')
  for i in range(5):cyl('Coins',(-.2+i*.07,1.1,1.9+i*.045),.13,.045,'gold')
  cube('Savings box',(1.2,1.5,2.15),(.75,.65,.65),'blue',.1)
  cube('Coin slot',(1.2,1.5,2.485),(.27,.04,.012),'dark',0)
  for i in range(5):
   o=cube('Book',(-5.4+i*.21,1.8,6.2),(.18,.6,.75),['paper','blue','red'][i%3]);o.rotation_euler[1]=-.08+i*.04
  # giant cloth sack, spool and scattered coins
  uv('Soft giant sack',(-6,0,.6),(.8,.6,.65),'paper')
  for i in range(6):cyl('Path coin',(-3+i*.5,-.8,.03),.1,.04,'gold')
 else:
  for i in range(3):
   x=-1.35+i*1.35
   cyl('Seed pot',(x,1.4,2.05),.42,.55,'clay')
   cyl('Pot rim',(x,1.4,2.33),.46,.09,'edge')
   bar('Stem',(x,1.4,2.35),(x,1.4,3.1+i*.2),.035,'leaf')
   for k in range(4):
    o=uv('Leaf',(x+(-1 if k%2 else 1)*.17,1.4,2.5+k*.15),(.24,.08,.1),'leaf');o.rotation_euler[1]=(-1 if k%2 else 1)*.5
  cube('Reserve chest',(-3,1,.48),(1,.8,.8),'blue',.12)
  cube('Chest strap',(-3,1,.9),(.15,.85,.06),'gold')
  for x in [-6.4,6]:
   bar('Pipe',(x,3,0),(x,3,8),.12,'gold')
 save('room'+str(level))
room(1);room(2)
reset()
# Original little explorer: teal cape, copper lantern, oversized explorer hat
for x in [-.16,.16]:
 cube('Boot',(x,-.06,.12),(.23,.36,.2),'dark',.06)
 bar('Leg',(x,0,.18),(x,0,.56),.075,'dark')
bpy.ops.mesh.primitive_cone_add(vertices=20,radius1=.42,radius2=.23,depth=.65,location=(0,0,.78));bpy.context.object.name='Teal cape';bpy.context.object.data.materials.append(M['cloth'])
uv('Face',(0,-.025,1.22),(.23,.21,.25),'skin')
uv('Hair',(0,.045,1.31),(.245,.2,.2),'dark')
for x in [-.075,.075]:uv('Eye',(x,-.214,1.25),(.022,.018,.028),'dark')
cyl('Hat brim',(0,0,1.45),.36,.07,'paper');cyl('Hat crown',(0,0,1.55),.24,.19,'paper')
bar('Arm',(.25,0,.98),(.47,-.1,.71),.07,'cloth');bar('Arm',(-.25,0,.98),(-.35,-.1,.67),.07,'cloth')
bar('Lantern grip',(.47,-.1,.71),(.47,-.1,.51),.025,'gold')
cube('Lantern',(.47,-.1,.41),(.18,.18,.23),'glow',.025)
for z in [.28,.54]:cube('Lantern cap',(.47,-.1,z),(.24,.24,.04),'gold')
save('explorer')
reset()
bpy.ops.mesh.primitive_torus_add(major_segments=24,minor_segments=8,location=(0,0,.4),major_radius=.2,minor_radius=.045);bpy.context.object.data.materials.append(M['gold'])
bar('Key shaft',(0,0,.2),(0,0,-.4),.045,'gold')
for z in [-.2,-.35]:bar('Key tooth',(0,0,z),(.17,0,z),.045,'gold')
save('key')
print('DREAMKEYS_MODELS_OK')
