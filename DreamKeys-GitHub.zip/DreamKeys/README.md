# 小小夢境：理財鑰匙 · Dream Keys

以 Godot 4.7.2 與 Blender 5.3.0 製作的原創 3D 理財教育遊戲。適合國小中高年級，約 10–15 分鐘。靜態 Web 版本可直接部署 GitHub Pages，無後端、無帳號、無付費 API。

## 遊戲

- 第一關「願望雜貨屋」：安排 100 元預算，買午餐與車票，至少儲蓄 20 元，不能超支。
- 第二關「種子投資室」：配置 100 枚代幣，保留至少 20 枚備用金，分散到至少兩種種子，並理解仍可能虧損。
- 各關解題成功才取得 KEY；走到房間右側的門，按互動開門。沒有 KEY 無法通關。
- 各關初始 100 分，每次未通過扣 10 分，最低 60 分。探索與時間不扣分。關卡分數與投資情境獲利無關。
- 前後測各 4 題，涵蓋需要與想要、預算計算、分散風險、虧損與備用金。成果畫面呈現每關分數、總分、前後答對題數及各觀念變化。可下載匿名 JSON 學習紀錄。
- 前測不提示正誤，後測提供觀念回饋。比較只代表本次練習表現，不是已證實的長期教學成效。

## 操作

WASD / 方向鍵移動；空白鍵跳躍；E 互動；Esc 關閉解謎。也可使用畫面下方按鈕。建議桌機或平板橫向遊玩，使用支援 WebGL 2 的近期瀏覽器。瀏覽器需先點擊遊戲才能播放聲音。

## GitHub Pages

已匯出的 `docs/` 包含所有網站檔案；相對路徑支援儲存庫子目錄。Web 為單執行緒版本，不需要 COOP/COEP 或 SharedArrayBuffer。

1. 將此專案推送到 GitHub 的 `main` 分支。
2. 儲存庫 **Settings → Pages → Build and deployment → Source** 選擇 **GitHub Actions**。
3. `.github/workflows/pages.yml` 會上傳 `docs/` 並發布；Actions 頁面可查看結果。若組織限制 Actions，需由管理者解除限制。
4. 網址通常為 `https://使用者名稱.github.io/儲存庫名稱/`。

另一種方式：Pages Source 選 **Deploy from a branch**、分支 **main**、資料夾 **/docs**，不需建置流程。

## 本機預覽

不能以 `file://` 直接雙擊 HTML。請在專案目錄執行：

```sh
python3 -m http.server 8000 --directory docs
```

然後開啟 `http://localhost:8000`。

## 編輯與重建

- Godot 開啟 `project.godot`。`scripts/main.gd` 是世界、互動及介面；`scripts/rules.gd` 是可測試的解題與計分規則。
- Blender 原始檔在 `source/blender/`；遊戲使用 `models/*.glb`，不依賴 Blender 外掛或背景 MCP。
- `source/build_models.py` 可由 Blender 背景模式重新產生所有模型。GLB 匯出後，Godot 重新匯入即可。
- 中文字型為 Noto Sans TC，授權見 `assets/OFL.txt`。若要加入新文字，請確認所用字型包含相關字元。
- 在 Godot 安裝 **4.7.2 Standard Export Templates**，Web preset 已使用標準模板路徑，再選 Export Project。必須保持 **Thread Support 關閉**、**Compatibility renderer**，輸出 `docs/index.html`。
- 匯出後執行 `python3 source/finish_web.py`，加入頁面輔助控制與 `.nojekyll`。

## 驗證

```sh
godot --headless --path . --script tests/test_rules.gd
godot --path . -- --capture
```

第一個測試涵蓋超支、缺必要支出、儲蓄不足、集中風險、錯誤理由、計分下限及前後測答案。第二個自動走過兩關與測驗，並將截圖存到專案上層。測試資料僅寫入本機 Godot 使用者資料區。

實際教學前仍應由教師確認閱讀難度，並邀請學生試玩。本專案未進行兒童玩家實測。

## 美術與聲音來源

角色（青綠披風、探險帽與提燈）、家具、種子、鑰匙均由本專案的 Blender 腳本原創製作；音效及環境和聲為程式合成。Little Nightmares 僅作為巨大物件比例與神祕空間的視覺參考；未使用其角色、模型、截圖或音樂作為遊戲素材。

評量不要求輸入姓名；不含分析追蹤或廣告。末次結果保存在瀏覽器本機，清除網站資料即可刪除。
